import { Link, Outlet, useNavigate } from 'react-router-dom'
import { ClerkProvider, SignedIn, SignedOut, UserButton } from '@clerk/clerk-react'
import { logo } from '../assets/index'

const PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY

if (!PUBLISHABLE_KEY) {
  throw new Error("Missing Publishable Key")
}

export default function RootLayout() {
  const navigate = useNavigate();

  return (
    <ClerkProvider
      routerPush={(to) => navigate(to)}
      routerReplace={(to) => navigate(to, { replace: true })}
      publishableKey={PUBLISHABLE_KEY}
    >
      <div className='h-screen overflow-auto flex flex-col'>
        <header className="w-full flex justify-between items-center bg-white sm:px-8 px-4 py-4 border-b border-b-[#e6ebf4]">
          <Link to="/">
            <img src={logo} alt="logo" className="w-28 object-contain" />
          </Link>

          <div className='flex items-center gap-2'>
            <SignedIn>
              <UserButton afterSignOutUrl='/sign-in' />
              <Link className='ml-2 bg-blue-500 text-white p-2 rounded' to="/create">Create</Link>
            </SignedIn>
            <SignedOut>
              <Link to="/sign-in">Sign In</Link>
              <Link className='ml-2 bg-blue-500 text-white p-2 rounded' to="/sign-up">Sign Up</Link>
            </SignedOut>
          </div>
        </header>
        <main className='p-4 flex-1'>
          <Outlet />
        </main>
      </div>
    </ClerkProvider>
  )
}
