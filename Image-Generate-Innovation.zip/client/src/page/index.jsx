import { SignedIn, SignedOut } from "@clerk/clerk-react";
import { Link } from "react-router-dom";

export default function IndexPage() {
  return (
    <div className='h-full grid place-items-center'>
      <div className="text-center">
        <h1 className="text-5xl mb-2 font-bold">Welcome to IGI</h1>
        <p>An Ai image generator app</p>
        <div className='mt-4'>
          <SignedOut>
            <Link className='bg-blue-500 text-white p-3 rounded' to="/sign-in">SignIn to IGI</Link>
          </SignedOut>
          <SignedIn>
            <Link className='bg-blue-500 text-white p-3 rounded' to="/dashboard">Go to dashboard</Link>
          </SignedIn>
        </div>
      </div>
    </div>
  )
}
