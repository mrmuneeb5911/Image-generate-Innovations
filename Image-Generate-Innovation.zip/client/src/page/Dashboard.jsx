import Home from './Home'

export default function DashboardPage() {
  return (
    <>
      <div className="sm:p-8 px-4 py-8 w-full bg-[#f9fafe] min-h-[calc(100vh-73px)]">
        <Home />
      </div>
    </>
  );
}
